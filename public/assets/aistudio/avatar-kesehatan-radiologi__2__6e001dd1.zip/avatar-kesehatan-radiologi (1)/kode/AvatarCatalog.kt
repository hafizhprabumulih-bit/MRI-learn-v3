package com.example.ui.avatar

import androidx.annotation.DrawableRes
import com.example.R

/** Satu pilihan avatar. [id] disimpan di DataStore (userAvatarId), jadi jangan diubah setelah dirilis. */
data class AvatarOption(
    val id: String,
    val label: String,
    @DrawableRes val drawableRes: Int
)

object AvatarCatalog {
    val options: List<AvatarOption> = listOf(
        AvatarOption("dokter_robot", "Dokter Robot", R.drawable.avatar_dokter_robot),
        AvatarOption("radiografer_mri", "Radiografer MRI", R.drawable.avatar_radiografer_mri),
        AvatarOption("radiolog", "Radiolog", R.drawable.avatar_radiolog),
        AvatarOption("fisikawan_medis", "Fisikawan Medis", R.drawable.avatar_fisikawan_medis),
        AvatarOption("ahli_neuro_mri", "Ahli Neuro-MRI", R.drawable.avatar_ahli_neuro_mri),
        AvatarOption("petugas_proteksi_radiasi", "Petugas Proteksi Radiasi", R.drawable.avatar_petugas_proteksi_radiasi),
        AvatarOption("ahli_jantung", "Ahli Jantung", R.drawable.avatar_ahli_jantung),
        AvatarOption("perawat", "Perawat", R.drawable.avatar_perawat),
        AvatarOption("dokter_bedah", "Dokter Bedah", R.drawable.avatar_dokter_bedah)
    )

    /** Mengembalikan null untuk id lama ("male", "female", dst.), sehingga kode lama tetap berjalan. */
    fun find(id: String): AvatarOption? = options.firstOrNull { it.id == id }
}
