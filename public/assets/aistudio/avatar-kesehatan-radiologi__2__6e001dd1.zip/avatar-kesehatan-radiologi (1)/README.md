# Paket Avatar Kesehatan dan Radiologi

Sembilan avatar robot bergaya sama dengan ilustrasi robot dokter Anda. Satu avatar berasal dari ilustrasi asli (latar dihapus), delapan lainnya digambar baru dengan palet yang sama (navy #062367, biru #43bafe, visor biru tua).

| id | Nama | Ciri |
|---|---|---|
| `dokter_robot` | Dokter Robot | Robot dokter asli (dipotong dari ilustrasi Anda, latar dihapus) |
| `radiografer_mri` | Radiografer MRI | Headset peredam bising MRI, magnet B0, ikon gantri MRI |
| `radiolog` | Radiolog | Jas putih dan film rontgen toraks |
| `fisikawan_medis` | Fisikawan Medis | Atom dan simbol B0, mata mengedip |
| `ahli_neuro_mri` | Ahli Neuro-MRI | Hologram otak dan ikon petir saraf |
| `petugas_proteksi_radiasi` | Petugas Proteksi Radiasi | Apron timbal, trefoil radiasi, kacamata pelindung, dosimeter |
| `ahli_jantung` | Ahli Jantung | Stetoskop dan jantung |
| `perawat` | Perawat | Topi perawat dan kotak P3K |
| `dokter_bedah` | Dokter Bedah | Topi bedah, lampu kepala, masker, scrub hijau |

## Isi folder

- `png_latar/` : PNG 512x512 berlatar warna. Semua bagian robot dan properti sudah muat di dalam lingkaran, jadi aman dipotong `CircleShape`. Pakai ini untuk avatar profil.
- `png_transparan/` : PNG transparan 512 dan 1024 untuk dipakai di atas latar lain.
- `svg/` : sumber vektor delapan avatar baru (bisa diedit di Figma, Illustrator, atau Inkscape). Avatar `dokter_robot` berupa raster karena berasal dari JPG.
- `android/res/drawable-nodpi/` : berkas `avatar_<id>.png` siap salin ke `app/src/main/res/drawable-nodpi/`.
- `web/avatar/` : berkas `<id>.png` siap salin ke `public/belajar_mri_web/avatar/`.
- `kode/AvatarCatalog.kt` : daftar id, label, dan drawable.
- `preview_potong_lingkaran.png` : pratinjau tampilan di dalam lingkaran.

## Memasang di Android

1. Salin isi `android/res/drawable-nodpi/` ke `app/src/main/res/drawable-nodpi/`.
2. Salin `kode/AvatarCatalog.kt` ke `app/src/main/java/com/example/ui/avatar/`.
3. Di `HomeScreen.kt`, tambahkan cabang `else` pada `when (state.userAvatarId)` agar id baru dikenali:

```kotlin
else -> {
    val opt = AvatarCatalog.find(state.userAvatarId)
    if (opt != null) {
        Image(
            painter = painterResource(id = opt.drawableRes),
            contentDescription = opt.label,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}
```

4. Di `AvatarDialog.kt`, tampilkan `AvatarCatalog.options` sebagai pilihan (misalnya di `LazyVerticalGrid` atau `FlowRow`). Tiap item memakai `painterResource(opt.drawableRes)`, dan saat dipilih mengisi `selectedId = opt.id`. Id lama ("male", "female") tetap berfungsi karena `find()` mengembalikan null untuk id itu.

Catatan: kode di atas belum dikompilasi di sini. Setelah ditempel, jalankan Gradle Sync dan sesuaikan nama impor bila perlu.

## Memasang di web

Salin `web/avatar/` ke `public/belajar_mri_web/avatar/`, lalu pakai `<img src="avatar/radiolog.png">` pada pilihan avatar di `index.html` dan `app.js`.

## Menambah avatar baru

Semua SVG memakai rangka yang sama (kepala, visor, badan, outline navy 9 px, kanvas 512x512). Salin salah satu file di `svg/`, ubah aksesorinya, lalu ekspor ke PNG 1024. Untuk versi `png_latar`, letakkan hasilnya di atas latar warna dan kecilkan sampai seluruh objek muat di lingkaran berdiameter 512.
